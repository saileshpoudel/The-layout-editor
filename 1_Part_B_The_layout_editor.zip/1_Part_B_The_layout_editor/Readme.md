# 1.2 Part B: The layout editor

* Task 1: Create layout variants  -->*(Project: HelloConstraint)*
* Coding challenge 1  -->*(Project: HelloConstraint)*
* Task 2: Change the layout to LinearLayout  -->*(Project: HelloConstraint)*
* Task 3: Change the layout to RelativeLayout  -->*(Project: HelloRelative)*
* Homework   -->*(Project: HelloConstraintHW)*
